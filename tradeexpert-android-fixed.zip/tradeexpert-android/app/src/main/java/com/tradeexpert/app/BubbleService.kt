package com.tradeexpert.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import kotlin.math.abs

/**
 * TRADEEXPERT floating bubble. One bubble only.
 *  - Shows over other apps while the bot is on.
 *  - Drag it anywhere; it stays where you leave it.
 *  - Tap it to open the bot console. Tap outside or the X to close it.
 *  - Turning the bot off removes it.
 */
class BubbleService : Service() {

    companion object {
        const val ACTION_PUSH = "com.tradeexpert.app.CONSOLE_PUSH"
        const val ACTION_BOT = "com.tradeexpert.app.CONSOLE_BOT"
        const val ACTION_CLEAR = "com.tradeexpert.app.CONSOLE_CLEAR"
        // Recent console lines, shown again when the console opens.
        private val history = ArrayList<Pair<String, String>>()
        private const val CHANNEL = "lh_bubble"
        private const val APP_URL = "https://tradeexpert-ea.co.za/ea-app"
        private const val NOTIFICATION_ID = 41

        // Runs when the console's Stop button is pressed (set by MainActivity).
        var stopAction: (() -> Unit)? = null

        // The one bubble on screen. Any older bubble is removed before a new one is added.
        var liveBubble: View? = null

        // Every overlay window the app adds is tracked here, so none can be left on screen.
        private val overlays = mutableListOf<View>()

        @Synchronized
        fun addOverlay(wm: WindowManager, v: View, lp: WindowManager.LayoutParams) {
            wm.addView(v, lp)
            overlays.add(v)
        }

        @Synchronized
        fun removeOverlay(wm: WindowManager, v: View) {
            runCatching { wm.removeView(v) }
            overlays.remove(v)
        }

        @Synchronized
        fun removeAllOverlays(wm: WindowManager) {
            overlays.toList().forEach { v -> runCatching { wm.removeView(v) } }
            overlays.clear()
        }

        // The last bot the website sent, shown when the console opens.
        @Volatile var lastBotName: String = ""
        @Volatile var lastBotPic: String = ""

        fun canDraw(ctx: Context) = Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(ctx)

        fun start(ctx: Context, openConsole: Boolean = false) {
            if (!canDraw(ctx)) return
            try {
                ContextCompat.startForegroundService(
                    ctx, Intent(ctx, BubbleService::class.java).putExtra("open", openConsole)
                )
            } catch (e: Exception) { }
        }

        fun stop(ctx: Context) {
            try { ctx.stopService(Intent(ctx, BubbleService::class.java)) } catch (e: Exception) { }
        }

        // A console line, shown in the console.
        fun push(ctx: Context, text: String, kind: String = "info") {
            synchronized(history) {
                history.add(text to kind)
                if (history.size > 60) history.removeAt(0)
            }
            ctx.sendBroadcast(
                Intent(ACTION_PUSH).setPackage(ctx.packageName).putExtra("text", text).putExtra("kind", kind)
            )
        }

        // Clears the console and its saved lines.
        fun clear(ctx: Context) {
            synchronized(history) { history.clear() }
            ctx.sendBroadcast(Intent(ACTION_CLEAR).setPackage(ctx.packageName))
        }

        // The bot's name and picture, shown in the console header.
        fun setBot(ctx: Context, name: String, picUrl: String? = null) {
            lastBotName = name
            lastBotPic = picUrl ?: ""
            ctx.sendBroadcast(
                Intent(ACTION_BOT).setPackage(ctx.packageName).putExtra("name", name).putExtra("pic", picUrl)
            )
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var bubble: ImageView
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var console: LinearLayout? = null
    private var web: WebView? = null
    private var pageReady = false
    private val waiting = mutableListOf<String>()
    private var destroyed = false
    private val handler = Handler(Looper.getMainLooper())

    private val overlayType
        get() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        try {
            startForeground(NOTIFICATION_ID, notification())
        } catch (e: Exception) {
            stopSelf()
            return
        }
        if (!canDraw(this)) {
            stopSelf()
            return
        }
        addBubble()
        // The console is built after the bubble is drawn, so the bubble shows at once.
        handler.post { if (!destroyed) buildConsole() }
        try {
            ContextCompat.registerReceiver(
                this, receiver, IntentFilter().apply { addAction(ACTION_PUSH); addAction(ACTION_BOT); addAction(ACTION_CLEAR) },
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (e: Exception) { }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val openNow = intent?.getBooleanExtra("open", false) == true
        val botOn = getSharedPreferences("bot", Context.MODE_PRIVATE).getBoolean("on", false)
        // The bot is off: nothing should be on screen. Remove everything and stop.
        if (!botOn && !openNow) {
            removeViews()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!::bubble.isInitialized) return START_NOT_STICKY
        // The bubble is added once, in onCreate. Later starts never add another one.
        if (openNow) handler.post { if (console?.isAttachedToWindow != true) toggleConsole() }
        // NOT_STICKY: if the app closes, Android must not restart the bubble on its own.
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        destroyed = true
        runCatching { unregisterReceiver(receiver) }
        removeViews()
        web?.let { runCatching { it.destroy() } }
        web = null
        super.onDestroy()
    }

    // Removes the bubble and the console from the screen.
    private fun removeViews() {
        removeAllOverlays(wm)
        liveBubble = null
    }

    // ---------------- notification (Android needs one while the service runs) ----------------
    private fun notification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Floating bot", NotificationManager.IMPORTANCE_MIN))
        }
        val open = PendingIntent.getActivity(this, 0, appIntent(), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.te_icon)
            .setContentTitle("")
            .setContentText("")
            .setContentIntent(open)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    private fun appIntent(): Intent {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(APP_URL))
            .setPackage(packageName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (i.resolveActivity(packageManager) != null) i
        else (packageManager.getLaunchIntentForPackage(packageName) ?: i).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    // ---------------- the bubble ----------------
    @SuppressLint("ClickableViewAccessibility")
    private fun addBubble() {
        // Only one bubble may exist: remove every older overlay first.
        removeAllOverlays(wm)
        bubble = ImageView(this).apply {
            setImageResource(R.drawable.bubble_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "TRADEEXPERT console"
        }
        bubbleLp = WindowManager.LayoutParams(
            dp(62), dp(62), overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = dp(180) }
        addOverlay(wm, bubble, bubbleLp)
        liveBubble = bubble
        bubble.setOnTouchListener(bubbleTouch())
    }

    // Drag to move (the bubble stays where it is left). A tap opens or closes the console.
    private fun bubbleTouch(): View.OnTouchListener {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        return View.OnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = bubbleLp.x; startY = bubbleLp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > dp(6) || abs(dy) > dp(6))) {
                        moved = true
                        hideConsole()
                    }
                    if (moved) {
                        bubbleLp.x = startX + dx.toInt()
                        bubbleLp.y = startY + dy.toInt()
                        runCatching { wm.updateViewLayout(v, bubbleLp) }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!moved) toggleConsole() else keepOnScreen()
                }
            }
            true
        }
    }

    // Keeps the bubble fully on screen, without moving it anywhere else.
    private fun keepOnScreen() {
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        bubbleLp.x = bubbleLp.x.coerceIn(0, w - dp(62))
        bubbleLp.y = bubbleLp.y.coerceIn(dp(24), h - dp(140))
        runCatching { wm.updateViewLayout(bubble, bubbleLp) }
    }

    // ---------------- the console ----------------
    @SuppressLint("SetJavaScriptEnabled")
    private fun buildConsole() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val wv = WebView(this).apply {
            setBackgroundColor(0)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "LH")
            webViewClient = object : WebViewClient() {
                // If Android kills the WebView's process, rebuild the console instead of closing the app.
                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                    handler.post { rebuildConsole() }
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    pageReady = true
                    waiting.clear()
                    replayHistory()
                    // Show the last bot the website sent, even if it was sent before the console opened.
                    val n = JSONObject.quote(lastBotName)
                    val p = JSONObject.quote(lastBotPic)
                    evaluateJavascript("lhSetBot($n,$p)", null)
                }
            }
            loadUrl("file:///android_asset/te-console.html")
        }
        // A fixed size: the TradeExpert console fills its box, so a wrap-size box would show nothing.
        box.addView(wv, LinearLayout.LayoutParams(dp(304), dp(420)))
        // Software drawing stops the console going blank between frames inside the overlay.
        wv.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        web = wv
        console = box
    }

    private fun rebuildConsole() {
        try {
            console?.let { c -> removeOverlay(wm, c) }
            web?.let { runCatching { it.destroy() } }
            web = null
            console = null
            pageReady = false
            waiting.clear()
            if (::bubble.isInitialized) bubble.visibility = View.VISIBLE
            buildConsole()
        } catch (e: Exception) { }
    }

    private fun consoleLp() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = ((resources.displayMetrics.widthPixels - dp(320)) / 2).coerceAtLeast(dp(8))
        y = (bubbleLp.y + dp(70)).coerceAtLeast(dp(24))
    }

    private fun toggleConsole() {
        val c = console ?: return
        if (c.isAttachedToWindow) {
            hideConsole()
            return
        }
        try {
            // A view can only be added once: detach it from any old parent first.
            (c.parent as? ViewGroup)?.removeView(c)
            addOverlay(wm, c, consoleLp())
            if (pageReady) replayHistory()
        } catch (e: Exception) {
            if (::bubble.isInitialized) bubble.visibility = View.VISIBLE
            return
        }
        if (::bubble.isInitialized) bubble.visibility = View.GONE
        c.alpha = 0f; c.translationY = dp(18).toFloat(); c.scaleX = .92f; c.scaleY = .92f
        c.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(450)
            .setInterpolator(PathInterpolator(.32f, .72f, 0f, 1f)).start()
    }

    private fun hideConsole() {
        val c = console ?: return
        removeOverlay(wm, c)
        if (::bubble.isInitialized) bubble.visibility = View.VISIBLE
    }

    // Sends all saved lines to the console in one call.
    private fun replayHistory() {
        val arr = org.json.JSONArray()
        synchronized(history) { history.forEach { (t, k) -> arr.put(org.json.JSONArray().put(t).put(k)) } }
        js("lhBulk(" + arr.toString() + ")")
    }

    // Sends a call to the console page. Lines that arrive before the page is ready wait for it.
    private fun js(code: String) {
        val wv = web ?: return
        if (pageReady) {
            wv.post { try { wv.evaluateJavascript(code, null) } catch (e: Exception) { } }
        } else if (waiting.size < 50) {
            waiting += code
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                ACTION_PUSH -> js(
                    "lhPush(${JSONObject.quote(i.getStringExtra("text") ?: "")},${JSONObject.quote(i.getStringExtra("kind") ?: "info")})"
                )
                ACTION_CLEAR -> js("lhClear()")
                ACTION_BOT -> js(
                    "lhSetBot(${JSONObject.quote(i.getStringExtra("name") ?: "")},${JSONObject.quote(i.getStringExtra("pic") ?: "")})"
                )
            }
        }
    }

    // Buttons inside the console page call these.
    inner class Bridge {
        @JavascriptInterface
        fun closeConsole() { handler.post { hideConsole() } }

        @JavascriptInterface
        fun openApp() { handler.post { hideConsole(); startActivity(appIntent()) } }

        @JavascriptInterface
        fun resize() { handler.post { console?.requestLayout() } }

        @JavascriptInterface
        fun cleared() {}

        @JavascriptInterface
        fun stopBot() { stopAction?.invoke() }

        // Moves the console window by dx, dy pixels (used when the console picture is dragged).
        @JavascriptInterface
        fun moveBy(dx: Int, dy: Int) {
            handler.post {
                try {
                    val c = console ?: return@post
                    if (!c.isAttachedToWindow) return@post
                    val lp = c.layoutParams as WindowManager.LayoutParams
                    lp.x += dx
                    lp.y += dy
                    wm.updateViewLayout(c, lp)
                } catch (e: Exception) { }
            }
        }
    }
}
