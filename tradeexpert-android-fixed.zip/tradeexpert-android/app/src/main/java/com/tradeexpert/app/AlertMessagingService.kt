package com.tradeexpert.app

import android.content.Context
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

// Receives signal lines from the server while the app is closed, and puts them in the console.
class AlertMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        saveToken(this, token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val line = message.data["message"] ?: return
        // Always show the server's line. Skip only an exact repeat within 10 seconds,
        // which can happen if the same push is delivered twice.
        val now = System.currentTimeMillis()
        if (line == lastLine && now - lastAt < 10_000) return
        lastLine = line
        lastAt = now
        try {
            // Diagnostic: shows that the phone received the server message, before the signal line itself.
            BubbleService.push(this, "[PUSH] received from server", "info")
            BubbleService.push(this, line, "signal")
            // Signal notification: shows even when the app is closed or in the background.
            Notifier.show(this, "TRADEEXPERT", line)
        } catch (e: Exception) { }
    }

    companion object {
        private var lastLine = ""
        private var lastAt = 0L

        // The phone's push token. The web page reads it through TradeExpertNative.getPushToken().
        fun saveToken(ctx: Context, token: String) {
            ctx.getSharedPreferences("push", Context.MODE_PRIVATE).edit().putString("token", token).apply()
        }

        fun savedToken(ctx: Context): String =
            ctx.getSharedPreferences("push", Context.MODE_PRIVATE).getString("token", "") ?: ""
    }
}
