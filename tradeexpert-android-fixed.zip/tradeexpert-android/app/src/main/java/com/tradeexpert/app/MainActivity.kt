package com.tradeexpert.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    // Gallery picker for web upload buttons (for example, a bot picture). Without this, the web
    // page's file button does nothing inside the app.
    private var fileCallback: android.webkit.ValueCallback<Array<android.net.Uri>>? = null
    private val filePicker = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        fileCallback?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        fileCallback = null
    }

    private var botState: Boolean? = null

    private val appUrl = "https://tradeexpert-ea.co.za/ea-app"
    private val appHost = "tradeexpert-ea.co.za"

    // Notifications are optional. The background service works either way.
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    // Bridge for the web page. The page calls window.TradeExpertNative.<method>(...)
    inner class BotBridge {

        // Console messages from the web page, shown in the bubble console.
        @JavascriptInterface
        fun push(rawText: String?, rawKind: String?) {
            // Empty values instead of null: a null from the web page used to crash the app.
            val text = rawText ?: ""
            val kind = rawKind ?: "info"
            // Signal lines are tagged so the console styles them as signals, as in Logical Host.
            val tone = if (text.contains("SIGNAL RECEIVED") || text.startsWith("[SIGNAL]")) "signal" else when (kind) {
                "exec", "ok", "success", "trade" -> "ok"
                "err", "error", "fail" -> "err"
                "warn", "warning" -> "warn"
                "signal" -> "signal"
                else -> "info"
            }
            try { BubbleService.push(this@MainActivity, text, tone) } catch (e: Exception) { }
        }

        // The bot's name and picture, shown in the bubble console header.
        @JavascriptInterface
        fun setBot(rawName: String?, rawPic: String?) {
            val name = rawName ?: ""
            val picUrl = rawPic ?: ""
            try { BubbleService.setBot(this@MainActivity, name, picUrl) } catch (e: Exception) { }
        }

        // The phone's push token, so the web page can save it for the server.
        @JavascriptInterface
        fun getPushToken(): String {
            // Return the saved token. If there is none yet, fetch it now and wait up to 5 seconds.
            // This runs on the web page's thread, not the main thread, so waiting is safe.
            val saved = AlertMessagingService.savedToken(this@MainActivity)
            if (saved.isNotEmpty()) return saved
            return try {
                val t = com.google.android.gms.tasks.Tasks.await(
                    com.google.firebase.messaging.FirebaseMessaging.getInstance().token,
                    5, java.util.concurrent.TimeUnit.SECONDS
                )
                if (!t.isNullOrEmpty()) {
                    AlertMessagingService.saveToken(this@MainActivity, t)
                    t
                } else ""
            } catch (e: Exception) { "" }
        }

        // The web console was cleared: clear the phone console too.
        @JavascriptInterface
        fun clear() {
            try { BubbleService.clear(this@MainActivity) } catch (e: Exception) { }
        }

        // The web page reports its bot on/off state.
        @JavascriptInterface
        fun setBotRunning(on: Boolean) {
            runOnUiThread { requestBot(on) }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onResume() {
        super.onResume()
        visible = true
    }

    override fun onPause() {
        visible = false
        super.onPause()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Store the push token so the web page can ask for it.
        try {
            com.google.firebase.messaging.FirebaseMessaging.getInstance().token.addOnSuccessListener { t ->
                if (!t.isNullOrEmpty()) AlertMessagingService.saveToken(this, t)
            }
        } catch (e: Exception) { }

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            }

            webViewClient = object : WebViewClient() {
                // Keep app pages inside the WebView; send other links to the browser.
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    val host = uri.host ?: return false
                    if (host == appHost || host.endsWith(".$appHost")) return false
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript(BOT_WATCH_JS, null)
                }

                // If Android kills the page's process, reload it instead of closing the app.
                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                    view?.post { view.reload() }
                    return true
                }

                // Simple offline screen if the app page cannot load.
                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) {
                        view?.loadDataWithBaseURL(null, offlineHtml(), "text/html", "UTF-8", null)
                    }
                }
            }
        }
        // Same bridge under both names, so web code written for Logical Host works here too.
        webView.addJavascriptInterface(BotBridge(), "LogicalHostNative")
        webView.addJavascriptInterface(BotBridge(), "TradeExpertNative")
        // Lets the web page open the gallery, for example to upload a bot picture.
        webView.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: android.webkit.ValueCallback<Array<android.net.Uri>>?,
                params: android.webkit.WebChromeClient.FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val type = if (params?.acceptTypes?.any { it.startsWith("image") } == true) "image/*" else "*/*"
                return try {
                    filePicker.launch(type)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    callback?.onReceiveValue(null)
                    false
                }
            }
        }

        // The bubble's STOP button presses the web page's STOP button.
        BubbleService.stopAction = {
            runOnUiThread { webView.evaluateJavascript(STOP_JS, null) }
        }

        // Login sessions depend on cookies.
        CookieManager.getInstance().setAcceptCookie(true)

        // Keep JavaScript timers running when the app is in the background.
        webView.resumeTimers()

        if (savedInstanceState == null) {
            // Fresh start (app was closed): load the latest web app, not a cached copy.
            webView.clearCache(true)
            webView.loadUrl(appUrl)
        } else {
            webView.restoreState(savedInstanceState)
        }

        // No native top bar: the bot is switched from the web page, through TradeExpertNative.
        setContentView(webView)

        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        KeepAliveService.start(this)
        askBatteryExemptionOnce()

        // Restore the last bot state, but only if overlay permission is still granted.
        val saved = getSharedPreferences("bot", Context.MODE_PRIVATE).getBoolean("on", false)
        applyBot(saved && Settings.canDrawOverlays(this))
    }

    // Turning the bot on needs "Display over other apps" first.
    private fun requestBot(on: Boolean) {
        if (on && !Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Allow display over other apps, then turn the bot on again",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        applyBot(on)
    }

    // One place that changes the bot: keeps the switch, the saved state, the bubble and the background service in step.
    private fun applyBot(on: Boolean) {
        if (botState == on) return
        botState = on
        getSharedPreferences("bot", Context.MODE_PRIVATE).edit().putBoolean("on", on).apply()
        try { KeepAliveService.setBot(this, on) } catch (e: Exception) { }
        try {
            if (on) BubbleService.start(this) else BubbleService.stop(this)
        } catch (e: Exception) { }
        if (on) askBatteryOnce()
    }

    // Asks once to be excluded from battery optimisation, so the bot keeps running in the background.
    private fun askBatteryOnce() {
        val prefs = getSharedPreferences("startup", Context.MODE_PRIVATE)
        if (prefs.getBoolean("battery_on_asked", false)) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        prefs.edit().putBoolean("battery_on_asked", true).apply()
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) { }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    // Asks once to be excluded from battery optimisation, so Android does not put the app to sleep.
    private fun askBatteryExemptionOnce() {
        val prefs = getSharedPreferences("startup", Context.MODE_PRIVATE)
        if (prefs.getBoolean("battery_asked", false)) return
        prefs.edit().putBoolean("battery_asked", true).apply()

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        }
    }

    // Back button goes back in the web app first, then exits.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    private fun offlineHtml() = """
        <html><body style="margin:0;height:100vh;display:flex;flex-direction:column;
        align-items:center;justify-content:center;background:#0a0d14;color:#e6f0ff;
        font-family:system-ui,sans-serif;text-align:center;gap:16px">
        <h2 style="letter-spacing:3px">TRADEEXPERT</h2>
        <p>Can't reach the app. Check your connection.</p>
        <a href="$appUrl" style="padding:12px 22px;border-radius:12px;background:#1e90ff;
        color:#fff;text-decoration:none;font-weight:700">Try again</a>
        </body></html>
    """.trimIndent()

    companion object {
        // Whether the app is on screen. Used so signal lines are not shown twice.
        @Volatile var visible = false

        // Clicks the web page's STOP button, from the bubble console.
        private const val STOP_JS = """(function(){var b=[].slice.call(document.querySelectorAll('button')).find(function(x){return (x.textContent||'').trim().toUpperCase()==='STOP';});if(b){b.click();return true;}return false;})();"""

        // Reports the web page's bot name and picture to the app, and keeps the web bubble hidden.
        private const val BOT_WATCH_JS = """
            (function () {
              if (window.__botWatch) return;
              window.__botWatch = true;
              var last = null;
              var lastBot = '';
              // Reads the bot's name and picture from the console card on the page, so they
              // reach the bubble even if the website call is missing.
              // The top bot card: its picture is the largest image near the top, and its name is the
              // largest text just below it. Works for round and octagon pictures.
              function findTopBot() {
                try {
                  var H = window.innerHeight, pic = null, best = 0;
                  document.querySelectorAll('img').forEach(function (img) {
                    if (img.closest('.bcon-wrap')) return;
                    var r = img.getBoundingClientRect();
                    if (r.width < 60 || r.top < -20 || r.top > H * 0.45 || r.bottom < H * 0.05) return;
                    var area = r.width * r.height;
                    if (area > best) { best = area; pic = img; }
                  });
                  var name = '', size = 0;
                  document.querySelectorAll('body *').forEach(function (el) {
                    if (el.closest('.bcon-wrap') || el.children.length > 0) return;
                    var t = (el.textContent || '').trim();
                    if (!t || t.length > 40) return;
                    var r = el.getBoundingClientRect();
                    if (r.width === 0 || r.top < 0 || r.top > H * 0.55) return;
                    var f = parseFloat(window.getComputedStyle(el).fontSize) || 0;
                    if (f > size) { size = f; name = t; }
                  });
                  if (!pic || !name) return null;
                  return { name: name, pic: pic.src || '' };
                } catch (e) { return null; }
              }
              function sendBot() {
                try {
                  // Keep the last bot until the top card shows another one (no default overwrite).
                  var top = findTopBot();
                  if (!top || !top.name) return;
                  var name = top.name, pic = top.pic;
                  var key = name + '|' + pic;
                  if (key !== lastBot) {
                    lastBot = key;
                    if (window.LogicalHostNative) window.LogicalHostNative.setBot(name, pic);
                  }
                } catch (e) {}
              }
              // Hides the web app's small round bot bubble, so only the app's bubble shows.
              function hideWebBubble() {
                try {
                  var W = window.innerWidth, H = window.innerHeight;
                  document.querySelectorAll('body *').forEach(function (el) {
                    if (el.getAttribute('data-lh-hidden') === '1') return;
                    var r = el.getBoundingClientRect();
                    if (r.width < 36 || r.width > 110 || Math.abs(r.width - r.height) > 8) return;
                    if (r.left < W * 0.6 || r.top < H * 0.45 || r.bottom > H) return;
                    var cs = window.getComputedStyle(el);
                    var round = parseFloat(cs.borderTopLeftRadius) >= r.width / 3 || cs.borderTopLeftRadius.indexOf('%') >= 0;
                    if (!round) return;
                    var hasPic = el.tagName === 'IMG' || !!el.querySelector('img') || (cs.backgroundImage && cs.backgroundImage !== 'none');
                    if (!hasPic) return;
                    el.setAttribute('data-lh-hidden', '1');
                    el.style.setProperty('display', 'none', 'important');
                  });
                } catch (e) {}
              }
              // Hides the web app's own console card every time it is shown or re-drawn.
              function hideWebConsole() {
                try {
                  if (!document.getElementById('lh-native-live-css')) {
                    var st = document.createElement('style');
                    st.id = 'lh-native-live-css';
                    st.textContent = '.bcon-wrap, .bcon-card, .lh-exec-overlay, .bc-more, .bc-feed, .bc-foot { display: none !important; visibility: hidden !important; pointer-events: none !important; }';
                    (document.head || document.documentElement).appendChild(st);
                  }
                  document.querySelectorAll('.bcon-wrap, .bcon-card, .lh-exec-overlay').forEach(function (el) {
                    el.style.setProperty('display', 'none', 'important');
                  });
                } catch (e) {}
              }
              hideWebConsole();
              setInterval(function () { hideWebBubble(); hideWebConsole(); }, 1000);
            })();
        """
    }
}
